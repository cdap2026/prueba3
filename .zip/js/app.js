document.addEventListener('DOMContentLoaded', () => {
  const dropZone = document.getElementById('dropZone');
  const dropZoneIdle = document.getElementById('dropZoneIdle');
  const dropZonePreview = document.getElementById('dropZonePreview');
  const imagePreview = document.getElementById('imagePreview');
  const fileInputUpload = document.getElementById('fileInputUpload');
  const fileInputCamera = document.getElementById('fileInputCamera');
  const btnTriggerUpload = document.getElementById('btnTriggerUpload');
  const btnTriggerCamera = document.getElementById('btnTriggerCamera');
  const btnChangeImage = document.getElementById('btnChangeImage');
  const actionFooter = document.getElementById('actionFooter');
  const btnIdentify = document.getElementById('btnIdentify');
  const loadingSection = document.getElementById('loadingSection');
  const resultSection = document.getElementById('resultSection');
  const btnNewScan = document.getElementById('btnNewScan');
  const btnShare = document.getElementById('btnShare');
  const btnFavorite = document.getElementById('btnFavorite');

  // Modales
  const cameraModal = document.getElementById('cameraModal');
  const cameraVideo = document.getElementById('cameraVideo');
  const cameraCanvas = document.getElementById('cameraCanvas');
  const btnCaptureShutter = document.getElementById('btnCaptureShutter');
  const btnCloseCamera = document.getElementById('btnCloseCamera');

  const historyModal = document.getElementById('historyModal');
  const btnOpenHistory = document.getElementById('btnOpenHistory');
  const btnCloseHistory = document.getElementById('btnCloseHistory');
  const btnClearHistory = document.getElementById('btnClearHistory');
  const historyListContainer = document.getElementById('historyListContainer');

  const settingsModal = document.getElementById('settingsModal');
  const btnOpenSettings = document.getElementById('btnOpenSettings');
  const btnCloseSettings = document.getElementById('btnCloseSettings');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const engineSelect = document.getElementById('engineSelect');
  const apiKeyContainer = document.getElementById('apiKeyContainer');
  const apiKeyInput = document.getElementById('apiKeyInput');

  let currentFile = null;
  let currentStream = null;
  let lastResult = null;

  engineSelect.value = localStorage.getItem('florascan_engine') || 'demo';
  apiKeyInput.value = localStorage.getItem('florascan_api_key') || '';
  toggleApiKeyField();

  // Subir imagen
  btnTriggerUpload.addEventListener('click', (e) => {
    e.stopPropagation();
    fileInputUpload.click();
  });

  // Tomar foto: en móviles usa la cámara nativa con capture="environment", en PC lanza la webcam
  btnTriggerCamera.addEventListener('click', (e) => {
    e.stopPropagation();
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (isMobile) {
      fileInputCamera.click();
    } else {
      openLiveCamera();
    }
  });

  fileInputUpload.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) handleSelectedImage(e.target.files[0]);
  });

  fileInputCamera.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) handleSelectedImage(e.target.files[0]);
  });

  btnChangeImage.addEventListener('click', (e) => {
    e.stopPropagation();
    resetUploadZone();
  });

  // Drag & drop
  ['dragenter', 'dragover'].forEach(name => {
    dropZone.addEventListener(name, (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
  });

  ['dragleave', 'drop'].forEach(name => {
    dropZone.addEventListener(name, (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });

  dropZone.addEventListener('drop', (e) => {
    if (e.dataTransfer && e.dataTransfer.files[0]) {
      handleSelectedImage(e.dataTransfer.files[0]);
    }
  });

  function handleSelectedImage(file) {
    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona una imagen válida (JPG, PNG o WebP).');
      return;
    }
    currentFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      imagePreview.src = e.target.result;
      dropZoneIdle.classList.add('d-none');
      dropZonePreview.classList.remove('d-none');
      actionFooter.classList.remove('d-none');
      resultSection.classList.add('d-none');
      actionFooter.scrollIntoView({ behavior: 'smooth' });
    };
    reader.readAsDataURL(file);
  }

  function resetUploadZone() {
    currentFile = null;
    fileInputUpload.value = '';
    fileInputCamera.value = '';
    imagePreview.src = '';
    dropZonePreview.classList.add('d-none');
    dropZoneIdle.classList.remove('d-none');
    actionFooter.classList.add('d-none');
    resultSection.classList.add('d-none');
  }

  // Cámara Web
  async function openLiveCamera() {
    try {
      cameraModal.classList.remove('d-none');
      currentStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 } },
        audio: false
      });
      cameraVideo.srcObject = currentStream;
    } catch (err) {
      closeLiveCamera();
      fileInputCamera.click();
    }
  }

  function closeLiveCamera() {
    if (currentStream) {
      currentStream.getTracks().forEach(track => track.stop());
      currentStream = null;
    }
    cameraModal.classList.add('d-none');
  }

  btnCloseCamera.addEventListener('click', closeLiveCamera);

  btnCaptureShutter.addEventListener('click', () => {
    if (!currentStream) return;
    cameraCanvas.width = cameraVideo.videoWidth || 640;
    cameraCanvas.height = cameraVideo.videoHeight || 480;
    const ctx = cameraCanvas.getContext('2d');
    ctx.drawImage(cameraVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);

    cameraCanvas.toBlob((blob) => {
      handleSelectedImage(blob);
      closeLiveCamera();
    }, 'image/jpeg', 0.9);
  });

  // Identificar
  btnIdentify.addEventListener('click', async () => {
    if (!currentFile) return;

    actionFooter.classList.add('d-none');
    loadingSection.classList.remove('d-none');
    resultSection.classList.add('d-none');
    loadingSection.scrollIntoView({ behavior: 'smooth' });

    try {
      const result = await window.plantIdentifierService.identify(currentFile);
      lastResult = result;
      displayResult(result);
      saveToHistory(result, imagePreview.src);
    } catch (error) {
      alert('Error en la identificación: ' + error.message);
      actionFooter.classList.remove('d-none');
    } finally {
      loadingSection.classList.add('d-none');
    }
  });

  function displayResult(res) {
    document.getElementById('confidenceBadge').innerHTML = `<i class="fa-solid fa-circle-check"></i> ${res.confidence}% Coincidencia`;
    document.getElementById('plantCommonName').textContent = res.commonName;
    document.getElementById('plantScientificName').textContent = res.scientificName;
    document.getElementById('plantDescription').textContent = res.description;

    document.getElementById('plantTags').innerHTML = `
      <span class="tag"><i class="fa-solid fa-seedling"></i> ${res.family}</span>
      <span class="tag"><i class="fa-solid fa-house"></i> ${res.habitat}</span>
    `;

    document.getElementById('plantLight').textContent = res.light;
    document.getElementById('plantWater').textContent = res.water;
    document.getElementById('plantTemp').textContent = res.temp;
    document.getElementById('plantToxicity').textContent = res.toxicity;
    document.getElementById('plantTip').textContent = res.tip;

    resultSection.classList.remove('d-none');
    resultSection.scrollIntoView({ behavior: 'smooth' });
  }

  btnNewScan.addEventListener('click', () => {
    resetUploadZone();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  btnShare.addEventListener('click', async () => {
    if (navigator.share && lastResult) {
      try {
        await navigator.share({
          title: `Planta: ${lastResult.commonName}`,
          text: `¡Mira esta ${lastResult.commonName} (${lastResult.scientificName}) identificada en FloraScan!`,
          url: window.location.href
        });
      } catch (e) {}
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('¡Enlace de FloraScan copiado al portapapeles!');
    }
  });

  btnFavorite.addEventListener('click', () => {
    const icon = btnFavorite.querySelector('i');
    if (icon.classList.contains('fa-regular')) {
      icon.classList.remove('fa-regular');
      icon.classList.add('fa-solid');
      btnFavorite.style.background = '#e74c3c';
      btnFavorite.style.color = '#fff';
    } else {
      icon.classList.remove('fa-solid');
      icon.classList.add('fa-regular');
      btnFavorite.style.background = '';
      btnFavorite.style.color = '';
    }
  });

  // Historial
  function saveToHistory(res, thumb) {
    const history = JSON.parse(localStorage.getItem('florascan_history') || '[]');
    history.unshift({
      id: Date.now(),
      commonName: res.commonName,
      scientificName: res.scientificName,
      date: new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }),
      thumbnail: thumb
    });
    if (history.length > 20) history.pop();
    localStorage.setItem('florascan_history', JSON.stringify(history));
  }

  btnOpenHistory.addEventListener('click', renderHistory);
  btnCloseHistory.addEventListener('click', () => historyModal.classList.add('d-none'));

  function renderHistory() {
    const history = JSON.parse(localStorage.getItem('florascan_history') || '[]');
    if (history.length === 0) {
      historyListContainer.innerHTML = '<p class="empty-state">No hay escaneos recientes todavía.</p>';
    } else {
      historyListContainer.innerHTML = history.map(item => `
        <div class="history-item">
          <img src="${item.thumbnail}" alt="${item.commonName}" />
          <div>
            <h5>${item.commonName}</h5>
            <span>${item.scientificName} · ${item.date}</span>
          </div>
        </div>
      `).join('');
    }
    historyModal.classList.remove('d-none');
  }

  btnClearHistory.addEventListener('click', () => {
    if (confirm('¿Vaciar historial de plantas escaneadas?')) {
      localStorage.removeItem('florascan_history');
      renderHistory();
    }
  });

  // Configuración
  btnOpenSettings.addEventListener('click', () => settingsModal.classList.remove('d-none'));
  btnCloseSettings.addEventListener('click', () => settingsModal.classList.add('d-none'));

  engineSelect.addEventListener('change', toggleApiKeyField);
  function toggleApiKeyField() {
    if (engineSelect.value === 'demo') {
      apiKeyContainer.classList.add('d-none');
    } else {
      apiKeyContainer.classList.remove('d-none');
    }
  }

  btnSaveSettings.addEventListener('click', () => {
    window.plantIdentifierService.setEngine(engineSelect.value, apiKeyInput.value.trim());
    settingsModal.classList.add('d-none');
    alert('Ajustes guardados correctamente.');
  });
});

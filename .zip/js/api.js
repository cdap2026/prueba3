// Servicio de Conexión a Motores Botánicos
class PlantIdentifierService {
  constructor() {
    this.engine = localStorage.getItem('florascan_engine') || 'demo';
    this.apiKey = localStorage.getItem('florascan_api_key') || '';
  }

  setEngine(engine, apiKey = '') {
    this.engine = engine;
    this.apiKey = apiKey;
    localStorage.setItem('florascan_engine', engine);
    localStorage.setItem('florascan_api_key', apiKey);
  }

  async identify(imageBlob) {
    if (this.engine === 'demo' || !this.apiKey) {
      return this.mockIdentify();
    }
    if (this.engine === 'plantnet') {
      return this.identifyWithPlantNet(imageBlob);
    } else if (this.engine === 'plantid') {
      return this.identifyWithPlantId(imageBlob);
    }
    return this.mockIdentify();
  }

  async mockIdentify() {
    // Retardo simulado de análisis de IA
    await new Promise(res => setTimeout(res, 1800));
    const randomIndex = Math.floor(Math.random() * PLANT_DATABASE.length);
    const plant = PLANT_DATABASE[randomIndex];
    const confidence = Math.floor(Math.random() * 8) + 91;

    return {
      confidence: confidence,
      commonName: plant.commonName,
      scientificName: plant.scientificName,
      family: plant.family,
      habitat: plant.habitat,
      description: plant.description,
      light: plant.light,
      water: plant.water,
      temp: plant.temp,
      toxicity: plant.toxicity,
      tip: plant.tip
    };
  }

  async identifyWithPlantNet(imageBlob) {
    const formData = new FormData();
    formData.append('images', imageBlob);
    const url = `https://my-api.plantnet.org/v2/identify/all?api-key=${encodeURIComponent(this.apiKey)}&lang=es`;

    const response = await fetch(url, { method: 'POST', body: formData });
    if (!response.ok) throw new Error(`Error en PlantNet API (${response.status})`);

    const data = await response.json();
    const topResult = data.results && data.results[0];
    if (!topResult) throw new Error('No se encontraron coincidencias en PlantNet.');

    const score = Math.round(topResult.score * 100);
    const species = topResult.species;

    return {
      confidence: score,
      commonName: (species.commonNames && species.commonNames[0]) || species.scientificNameWithoutAuthor,
      scientificName: species.scientificNameWithoutAuthor,
      family: species.family.scientificNameWithoutAuthor,
      habitat: 'Según región de origen',
      description: `Identificación botánica proporcionada por Pl@ntNet con un ${score}% de certeza.`,
      light: 'Buena luz solar indirecta',
      water: 'Riego moderado con buen sustrato drenante',
      temp: '15°C - 26°C',
      toxicity: 'Verificar por especie específica',
      tip: 'Mantén un registro periódico de crecimiento y floración.'
    };
  }

  async identifyWithPlantId(imageBlob) {
    const base64 = await this.blobToBase64(imageBlob);
    const response = await fetch('https://api.plant.id/v2/identify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Api-Key': this.apiKey },
      body: JSON.stringify({
        images: [base64],
        modifiers: ['crops_fast', 'similar_images'],
        plant_details: ['common_names', 'url', 'wiki_description', 'taxonomy']
      })
    });

    if (!response.ok) throw new Error(`Error en Plant.id (${response.status})`);
    const data = await response.json();
    const suggestion = data.suggestions && data.suggestions[0];
    if (!suggestion) throw new Error('No se pudo identificar la planta.');

    return {
      confidence: Math.round(suggestion.probability * 100),
      commonName: (suggestion.plant_details.common_names && suggestion.plant_details.common_names[0]) || suggestion.plant_name,
      scientificName: suggestion.plant_name,
      family: suggestion.plant_details.taxonomy ? suggestion.plant_details.taxonomy.family : 'N/A',
      habitat: 'Variable según especie',
      description: suggestion.plant_details.wiki_description ? suggestion.plant_details.wiki_description.value : 'Sin descripción adicional.',
      light: 'Iluminación natural adecuada',
      water: 'Riego adaptado a la sequedad del sustrato',
      temp: '18°C a 25°C',
      toxicity: 'Precaución general con mascotas',
      tip: 'Gira la maceta un cuarto de vuelta semanalmente para un crecimiento homogéneo.'
    };
  }

  blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result.split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
}

window.plantIdentifierService = new PlantIdentifierService();
